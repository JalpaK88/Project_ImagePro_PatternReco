# Use this code for Q : 3_b intruder detection 
from PIL import Image
import glob
import numpy as np
import matplotlib.pyplot as plt
import os 

# Training of images
# Read training images
Train_img_total = 1119 #after removing the 50 subject, 85 images from 1204

# size of each image in dataset
Size_img = 2880 # use this for high resolution 48 * 60
# Size_img = 320 # use this for low resolution 16 * 20

# Use this path for high resolution
Train_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Faces_New_dataset\_fa_H\*.pgm'

# Use this path for low resolution
# Train_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Faces_New_dataset\_fa_L\*.pgm'

Train_img_name = []
Train_img_pixel = np.zeros((Size_img,Train_img_total))
Count = 0 
for filename in glob.glob(Train_img_path): 
    img = Image.open(filename)
    Train_img_name.append(filename)
    Train_img_pixel[:,Count] = img.getdata()
    Count = Count+1
for Count in range(0,Train_img_total):
    Train_img_name[Count] = os.path.basename(Train_img_name[Count]) # extraxct the file name from the path 
    
# Calculate the average face
avg_face = Train_img_pixel.sum(axis=1)/Train_img_total

# Show and save the average face
avg_face_img = Image.new(img.mode,img.size)
avg_face_img.putdata(np.int_(255*(avg_face-np.min(avg_face))/(np.max(avg_face)-np.min(avg_face))))

save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
name = 'Avg_Face_updated'
# name = 'Avg_Face_low_updated'
filepath = save_path + name + '.png'
avg_face_img.save(filepath, format="png")
avg_face_img.show()

# subtract the average face from the training faces, calculated phi
A = (Train_img_pixel.T-avg_face).T

# Calculate eigenvectors and eigenvalues
Mu,v = np.linalg.eig(A.T@A) # eigenvalues and eigenvectors of A.T*A
idx = Mu.argsort()[::-1] # arrange from eigenvalues in decending order largest to smallest
Mu = Mu[idx]
v = v[:,idx]

lamda = Mu # eigenvalues of A*A.T
u = A@v  # eigenvectors of A*A.T

# Normalize the eigenvectors to unit vectors   
norm = np.linalg.norm(u,axis=0)
u = u/norm 

# Calculate the projection-coefficients omega vectors correponding to the training images
Train_Proj_coef = (A.T@u).T  # the transpose ().T on omega is applied to have each column yi corresponding to an image

# Reconstruction check
Train_Img = Train_img_pixel[:,1] 
Reconstructed_Img = Train_Proj_coef[:,1]@u.T + avg_face # add average image for reconstruction
Reconstruction_Error = np.linalg.norm(Train_Img-Reconstructed_Img)/Size_img
print('reconstruction error for updated dataset:', Reconstruction_Error)

# Initialize parameters
T = 0.95 
Total_min_distance = []
Tr_min = 0; Tr_max = 0.56; N = 10
# Tr_min = 0; Tr_max = 0.15; N = 10
Tr = np.linspace(Tr_min,Tr_max,num=N)
r = [40]
# r = (np.rint(np.linspace(1,50,25))).astype(int) # rank r from 1 to 50
FP = np.zeros(len(Tr))
TP = np.zeros(len(Tr))
Performance = np.zeros(len(r))

# Number of eigenvectors that preserves at least T = 95% of the information
threshold = 0
Num_of_Eigvector = 0 
while threshold <= T:
    Num_of_Eigvector = Num_of_Eigvector+1
    threshold = np.sum(lamda[0:Num_of_Eigvector])/np.sum(lamda)

# read test images
Test_img_total = 1196

# Use this path for High resolution
Test_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Faces_New_dataset\_fb_H\*.pgm' 

# Use this path for low resolution
# Test_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Faces_New_dataset\_fb_L\*.pgm'

Test_img_name = []
Train_img_pixel = np.zeros((Size_img,Test_img_total))
# Test images
Count = 0    
for filename in glob.glob(Test_img_path): 
    im=Image.open(filename)
    Test_img_name.append(filename)
    Train_img_pixel[:,Count] = im.getdata()
    Count = Count+1
for Count in range(0,Test_img_total):
    Test_img_name[Count] = os.path.basename(Test_img_name[Count]) # extraxct the file name from the path 

# Match test and training image file names
Train_img_name2 = []
Count = 0 
for filename in glob.glob(Train_img_path): 
    Train_img_name2.append(filename)
    Count = Count+1
for Count in range(0,Train_img_total):
    Train_img_name2[Count] = os.path.basename(Train_img_name2[Count]) # extraxct the file name from the path 
    Train_img_name2[Count] = Train_img_name2[Count].replace('fa','fb') 

# Calculate FP and TP
train_test = 0  # a counter for plotting the matched/mismatched images  
for intruder in Tr:
    for Count in range(0,len(r)):
        for Count_2 in range(0,Test_img_total):
            Train_img_pixel_Centered = Train_img_pixel[:,Count_2]-avg_face
            Test_Proj_coef = Train_img_pixel_Centered@u[:,0:Num_of_Eigvector]

            # Calculate Mahalanobis Distance between current test image and each training image
            Match_distance = np.zeros(Train_img_total)
            for Count_3 in range(0,Train_img_total):
                for Count_4 in range(0,Num_of_Eigvector):
                    Match_distance[Count_3] += (Test_Proj_coef[Count_4]-Train_Proj_coef[Count_4,Count_3])**2/lamda[Count_4]
            Closed_match_index = np.argsort(Match_distance)
            Total_min_distance.append(Match_distance[Closed_match_index[0]])
            Test_image_name = os.path.basename(Test_img_name[Count_2]) # name of the test image
            
            # compare matching distance with threshold 
            if  Match_distance[Closed_match_index[0]]<intruder: 
                if Test_image_name not in list(np.array(Train_img_name2)):
                    FP[train_test] += 1
                if Test_image_name in list(np.array(Train_img_name2)):
                    TP[train_test] += 1
    train_test = train_test+1

#normalized FP,TP, Tr
normalized_FP = FP / np.max(FP)
normalized_TP = TP / np.max(TP)
normalized_Tr = Tr / np.max(Tr)

# Plot the CMC curve
fig, ax = plt.subplots()
plt.plot(normalized_FP, normalized_TP, 'r', linewidth=5)
plt.plot(normalized_Tr, normalized_Tr, 'g', linewidth=5)
# plt.plot(FP/max(FP),TP/max(TP),'r', linewidth=5)
# plt.plot(Tr/max(Tr),Tr/max(Tr),'g', linewidth=5)
ax.set_aspect('equal')
plt.ylim([0,1])
plt.xlim([0,1])
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
plt.show()