from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Load an image both boat and f_16
image_path_boat = '/home/pratik/courses/674/program/database/pgm/boat.pgm'
image_path_f_16 = '/home/pratik/courses/674/program/database/pgm/f_16.pgm'

image_boat = Image.open(image_path_boat)
image_f_16 = Image.open(image_path_f_16)

# Convert the both image to a NumPy array
image_array_boat = np.array(image_boat)
image_array_f_16 = np.array(image_f_16)

# Create a figure with subplots for the original image, equalized image
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))

# Plot the original image boat and f_16
ax1.imshow(image_array_boat, cmap='gray')
ax1.set_title('Original Boat Image')
ax1.axis('off')

ax3.imshow(image_array_f_16, cmap='gray')
ax3.set_title('Original f_16 Image')
ax3.axis('off')

# Calculate the histogram of boat and f_16 image
histogram_boat = np.zeros(256, dtype=int)
for pixel_value in image_array_boat.flatten():
    histogram_boat[pixel_value] += 1

histogram_f_16 = np.zeros(256, dtype=int)
for pixel_value in image_array_f_16.flatten():
    histogram_f_16[pixel_value] += 1

# Calculate the cumulative distribution function (CDF) of boat image from the histogram
cdf_boat = np.zeros(256, dtype=int)
cdf_boat[0] = histogram_boat[0]
for i in range(1, 256):
    cdf_boat[i] = cdf_boat[i - 1] + histogram_boat[i]

# Calculate the cumulative distribution function (CDF) of f_16 image from the histogram
cdf_f_16 = np.zeros(256, dtype=int)
cdf_f_16[0] = histogram_f_16[0]
for j in range(1, 256):
    cdf_f_16[j] = cdf_f_16[j - 1] + histogram_f_16[j]

# # Calculate the cumulative distribution function (CDF) from the histogram
# cdf_boat = np.cumsum(histogram_boat)

# # Calculate the cumulative distribution function (CDF) from the histogram
# cdf_f_16 = np.cumsum(histogram_f_16)

# Calculate the total number of pixels in boat image
total_pixels_boat = image_array_boat.size

# Calculate the total number of pixels in f_16 image
total_pixels_f_16 = image_array_f_16.size

# Perform histogram equalization on boat image
equalized_image_boat = (cdf_boat[image_array_boat] / total_pixels_boat * 255).astype(np.uint8)

# Perform histogram equalization on f_16 image
equalized_image_f_16 = (cdf_f_16[image_array_f_16] / total_pixels_f_16 * 255).astype(np.uint8)

# Plot the equalized boat image
ax2.imshow(equalized_image_boat, cmap='gray')
ax2.set_title('Equalized Boat Image')
ax2.axis('off')

# Plot the equalized f_16 image
ax4.imshow(equalized_image_f_16, cmap='gray')
ax4.set_title('Equalized f_16 Image')
ax4.axis('off')


plt.tight_layout()
plt.show()
