import numpy as np

def ranf(m):
    return m * np.random.rand()

def box_muller_transform(mu, sigma):
    u1 = ranf(1)
    u2 = ranf(1)
    z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
    z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)
    return z0 * np.sqrt(sigma) + mu

def generate_2d_gaussian_samples(mu, sigma, num_samples):
    samples = []
    for _ in range(num_samples):
        x, y = box_muller_transform(mu[0], sigma[0, 0]), box_muller_transform(mu[1], sigma[1, 1])
        samples.append([x, y])
    return np.array(samples)

# Parameters for data set A
mu1 = np.array([1, 1])
sigma1 = np.array([[1, 0], [0, 1]])

mu2 = np.array([4, 4])
sigma2 = np.array([[4, 0], [0, 8]])

num_samples_class1 = 60000
num_samples_class2 = 140000

# Generate data set A
class1_data = generate_2d_gaussian_samples(mu1, sigma1, num_samples_class1)
class2_data = generate_2d_gaussian_samples(mu2, sigma2, num_samples_class2)

# Calculate prior probabilities
prior_prob_class1 = num_samples_class1 / (num_samples_class1 + num_samples_class2)
prior_prob_class2 = num_samples_class2 / (num_samples_class1 + num_samples_class2)

# Define the discriminant function
def discriminant_function(x, sigma_inv, mu, sigma_det, prior_prob):
    # Calculate Wi
    W_i = -0.5 * sigma_inv
    # Calculate wi
    w_i = np.dot(sigma_inv, mu)
    # Calculate wi0
    w_i0 = -0.5 * np.dot(mu.T, np.dot(sigma_inv, mu)) - 0.5 * np.log(sigma_det) + np.log(prior_prob)
    
    # Calculate quadratic part
    quadratic_part = np.dot(np.dot(x.T, W_i), x)
    # Calculate linear part
    linear_part = np.dot(w_i.T, x)
    # Add constant term
    discriminant_val = quadratic_part + linear_part + w_i0
    
    return discriminant_val

# Bayes classification
misclassifications_class1 = 0
misclassifications_class2 = 0

for sample in class1_data:
    discriminant_val_class1 = discriminant_function(sample, np.linalg.inv(sigma1), mu1, np.linalg.det(sigma1), prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, np.linalg.inv(sigma2), mu2, np.linalg.det(sigma2), prior_prob_class2)
    if discriminant_val_class1 < discriminant_val_class2:
        misclassifications_class1 += 1

for sample in class2_data:
    discriminant_val_class1 = discriminant_function(sample, np.linalg.inv(sigma1), mu1, np.linalg.det(sigma1), prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, np.linalg.inv(sigma2), mu2, np.linalg.det(sigma2), prior_prob_class2)
    if discriminant_val_class1 > discriminant_val_class2:
        misclassifications_class2 += 1

# Calculate misclassification rates
misclassification_rate_class1 = misclassifications_class1 / num_samples_class1
misclassification_rate_class2 = misclassifications_class2 / num_samples_class2
total_misclassifications = misclassifications_class1 + misclassifications_class2
total_misclassification_rate = (misclassifications_class1 + misclassifications_class2) / (num_samples_class1 + num_samples_class2)

# percentage of misclassification rates
misclassification_percentage_class1 = misclassification_rate_class1 * 100
misclassification_percentage_class2 = misclassification_rate_class2 * 100
total_misclassification_percentage = total_misclassification_rate * 100

# print misclassification rates
print("Misclassification for Class 1:", misclassifications_class1)
print("Misclassification for Class 2:", misclassifications_class2)
print("Total misclassification:", total_misclassifications)

print("Misclassification rate for Class 1:", misclassification_rate_class1)
print("Misclassification rate for Class 2:", misclassification_rate_class2)
print("Total misclassification rate:", total_misclassification_rate)

print("Percentage of misclassification for class 1:", misclassification_percentage_class1)
print("Percentage of misclassification for class 2:", misclassification_percentage_class2)
print("Percentage of misclassification total:", total_misclassification_percentage)