import numpy as np

def ranf(m):
    return m * np.random.rand()

# Function to generate samples from a 2D Gaussian distribution using Box-Muller transformation
def box_muller_transform(mu, sigma):
    u1 = ranf(1)
    u2 = ranf(1)
    z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
    z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)
    return z0 * np.sqrt(sigma) + mu

def generate_2d_gaussian_samples(mu, sigma, num_samples):
    samples = []
    for _ in range(num_samples):
        x, y = box_muller_transform(mu[0], sigma[0, 0]), box_muller_transform(mu[1], sigma[1, 1])
        samples.append([x, y])
    return np.array(samples)

# Parameters
mu1 = np.array([1, 1])
Sigma1 = np.array([[1, 0], [0, 1]])

mu2 = np.array([4, 4])
Sigma2 = np.array([[1, 0], [0, 1]])

num_samples_class1 = 60000
num_samples_class2 = 140000

# Generate samples for class 1
samples_class1 = generate_2d_gaussian_samples(mu1, Sigma1, num_samples_class1)

# Generate samples for class 2
samples_class2 = generate_2d_gaussian_samples(mu2, Sigma2, num_samples_class2)

# True labels (0 for class 1, 1 for class 2)
true_labels = np.hstack((np.zeros(num_samples_class1), np.ones(num_samples_class2)))

# # Euclidean distance classifier
# def euclidean_distance(x, mu):
#     return np.linalg.norm(x - mu)

# # other way to calculate the euclidean distance
# def euclidean_distance(x, mu):
#     sum_sq = np.sum(np.square(x - mu))
 
# # Doing squareroot
#     return(np.sqrt(sum_sq))

# define Euclidean distance classifier
def euclidean_distance(x, mu):
    return np.sqrt(np.sum((x - mu)**2))

def classify_euclidean(samples, class1_mean, class2_mean):
    predicted_labels = []
    for sample in samples:
        distance_to_class1 = euclidean_distance(sample, class1_mean)
        distance_to_class2 = euclidean_distance(sample, class2_mean)
        if distance_to_class1 > distance_to_class2:
            predicted_labels.append(1)  # Class 2
        else:
            predicted_labels.append(0)  # Class 1
    return np.array(predicted_labels)

# Compute class means
class1_mean = np.mean(samples_class1, axis=0)
class2_mean = np.mean(samples_class2, axis=0)

# # Classify using Euclidean distance classifier
# predicted_labels_euclidean = classify_euclidean(np.vstack((samples_class1, samples_class2)), class1_mean, class2_mean)

# # Misclassification of each class
# misclassification_class1 = np.sum((predicted_labels_euclidean[:num_samples_class1] != 0))
# misclassification_class2 = np.sum((predicted_labels_euclidean[num_samples_class1:] != 1))

# Classify using Euclidean distance classifier and calculate misclassification
misclassification_class1 = 0
misclassification_class2 = 0

# Loop through samples from class 1
for sample in samples_class1:
    distance_to_class1 = euclidean_distance(sample, class1_mean)
    distance_to_class2 = euclidean_distance(sample, class2_mean)
    if distance_to_class1 > distance_to_class2:
        misclassification_class1 += 1

# Loop through samples from class 2
for sample in samples_class2:
    distance_to_class1 = euclidean_distance(sample, class1_mean)
    distance_to_class2 = euclidean_distance(sample, class2_mean)
    if distance_to_class2 > distance_to_class1:
        misclassification_class2 += 1

# Misclassification rate for each class
misclassification_rate_class1 = misclassification_class1 / num_samples_class1
misclassification_rate_class2 = misclassification_class2 / num_samples_class2

# Total misclassification
total_misclassification = misclassification_class1 + misclassification_class2

# Total misclassification rate
total_misclassification_rate = total_misclassification / (num_samples_class1 + num_samples_class2)

# percentage of misclassification rates
misclassification_percentage_class1 = misclassification_rate_class1 * 100
misclassification_percentage_class2 = misclassification_rate_class2 * 100
total_misclassification_percentage = total_misclassification_rate * 100

print("Misclassification of Class 1:", misclassification_class1)
print("Misclassification of Class 2:", misclassification_class2)
print("Total misclassification:", total_misclassification)

print("Misclassification rate of Class 1:", misclassification_rate_class1)
print("Misclassification rate of Class 2:", misclassification_rate_class2)
print("Total misclassification rate:", total_misclassification_rate)

print("Percentage of misclassification for class 1:", misclassification_percentage_class1)
print("Percentage of misclassification for class 2:", misclassification_percentage_class2)
print("Percentage of misclassification total:", total_misclassification_percentage)