from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Load an image both boat and f_16
image_path_boat = '/home/pratik/courses/674/program/database/pgm/boat.pgm'
image_path_f_16 = '/home/pratik/courses/674/program/database/pgm/f_16.pgm'
image_boat = Image.open(image_path_boat)
image_f_16 = Image.open(image_path_f_16)


# Convert the boat image to a NumPy array
image_array_boat = np.array(image_boat)

# Convert the f_16 image to a NumPy array
image_array_f_16 = np.array(image_f_16)

# Create a figure with subplots for the original image, equalized image, and histograms
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

# # Plot the original boat image
# axes[0, 0].imshow(image_array_boat, cmap='gray')
# axes[0, 0].set_title('Original Boat Image')
# axes[0, 0].axis('off')

# # Plot the original f_16 image
# axes[1,0].imshow(image_array_f_16, cmap='gray')
# axes[1,0].set_title('Original f_16 Image')
# axes[1,0].axis('off')

# Calculate the histogram of boat image (frequency of each pixel value)
histogram_boat = np.zeros(256, dtype=int)
for pixel_value in image_array_boat.flatten():
    histogram_boat[pixel_value] += 1

# Calculate the histogram of f_16 image (frequency of each pixel value)
histogram_f_16 = np.zeros(256, dtype=int)
for pixel_value in image_array_f_16.flatten():
    histogram_f_16[pixel_value] += 1

# Calculate the cumulative distribution function (CDF) of boat image from the histogram
cdf_boat = np.zeros(256, dtype=int)
cdf_boat[0] = histogram_boat[0]
for i in range(1, 256):
    cdf_boat[i] = cdf_boat[i - 1] + histogram_boat[i]

# Calculate the cumulative distribution function (CDF) of f_16 image from the histogram
cdf_f_16 = np.zeros(256, dtype=int)
cdf_f_16[0] = histogram_f_16[0]
for j in range(1, 256):
    cdf_f_16[j] = cdf_f_16[j - 1] + histogram_f_16[j]

# # Calculate the cumulative distribution function (CDF) from the histogram
# cdf1 = np.cumsum(histogram1)

# # Calculate the cumulative distribution function (CDF) from the histogram
# cdf2 = np.cumsum(histogram2)

# Calculate the total number of pixels in the boat image
total_pixels_boat = image_array_boat.size

# Calculate the total number of pixels in the f_16 image
total_pixels_f_16 = image_array_f_16.size

# Perform histogram equalization on boat image
equalized_image_boat = (cdf_boat[image_array_boat] / total_pixels_boat * 255).astype(np.uint8)

# Perform histogram equalization on f_16 image
equalized_image_f_16 = (cdf_f_16[image_array_f_16] / total_pixels_f_16 * 255).astype(np.uint8)

# # Plot the equalized boat image
# axes[0,1].imshow(equalized_image_boat, cmap='gray')
# axes[0,1].set_title('Equalized Boat Image')
# axes[0,1].axis('off')

# # Plot the equalized f_16 image
# axes[1,1].imshow(equalized_image_f_16, cmap='gray')
# axes[1,1].set_title('Equalized f_16 Image')
# axes[1,1].axis('off')

# Plot the histogram of the original boat image

axes[0,0].set_title('Histogram of Original Boat Image')
axes[0,0].set_xlabel('Pixel Value')
axes[0,0].set_ylabel('Frequency')
axes[0,0].bar(range(256), histogram_boat, color='gray', alpha=0.7)

# Plot the histogram of the original f_16 image

axes[1,0].set_title('Histogram of Original f_16 Image')
axes[1,0].set_xlabel('Pixel Value')
axes[1,0].set_ylabel('Frequency')
axes[1,0].bar(range(256), histogram_f_16, color='gray', alpha=0.7)

# Calculate the histogram of the equalized boat image
equalized_histogram_boat = np.zeros(256, dtype=int)
for pixel_value in equalized_image_boat.flatten():
    equalized_histogram_boat[pixel_value] += 1

# Calculate the histogram of the equalized f_16 image
equalized_histogram_f_16 = np.zeros(256, dtype=int)
for pixel_value in equalized_image_f_16.flatten():
    equalized_histogram_f_16[pixel_value] += 1

# Plot the histogram of the equalized boat image

axes[0,1].set_title('Histogram of Equalized Boat Image')
axes[0,1].set_xlabel('Pixel Value')
axes[0,1].set_ylabel('Frequency')
axes[0,1].bar(range(256), equalized_histogram_boat, color='gray', alpha=0.7)

# Plot the histogram of the equalized f_16 image

axes[1,1].set_title('Histogram of Equalized f_16 Image')
axes[1,1].set_xlabel('Pixel Value')
axes[1,1].set_ylabel('Frequency')
axes[1,1].bar(range(256), equalized_histogram_f_16, color='gray', alpha=0.7)

plt.tight_layout()
plt.show()
