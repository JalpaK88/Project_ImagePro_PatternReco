# Use this code for Experiment c-I to IV
from PIL import Image
import glob
import numpy as np
import matplotlib.pyplot as plt
import xlsxwriter
import os 

# Training of images
# Read training images
Train_img_total = 1204
Size_img = 320 # 16 * 20
Train_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fa_L\*.pgm'
Train_img_name = []
Train_img_pixel = np.zeros((Size_img,Train_img_total))
Count = 0 
for filename in glob.glob(Train_img_path): 
    img = Image.open(filename)
    Train_img_name.append(filename)
    Train_img_pixel[:,Count] = img.getdata()
    Count = Count+1
for Count in range(0,Train_img_total):
    Train_img_name[Count] = os.path.basename(Train_img_name[Count]) # extraxct the file name from the path 
    
# Calculate the average face
avg_face = Train_img_pixel.sum(axis=1)/Train_img_total

# # Reshape the average face to match the dimensions of a single image
# avg_face_reshaped = avg_face.reshape((img.height, img.width))

# # Plot the average face
# plt.figure(figsize=(8, 8))
# plt.imshow(avg_face_reshaped, cmap='gray')
# plt.title('Average Face')
# plt.axis('off')
# plt.show()

# Show and save the average face
avg_face_img = Image.new(img.mode,img.size)
avg_face_img.putdata(np.int_(255*(avg_face-np.min(avg_face))/(np.max(avg_face)-np.min(avg_face))))
save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
name = 'Avg_Face_low'
filepath = save_path + name + '.png'
avg_face_img.save(filepath, format="png")
# avg_face_img.show()

# subtract the average face from the training faces, calculated phi
A = (Train_img_pixel.T-avg_face).T

# Calculate eigenvectors and eigenvalues
Mu,v = np.linalg.eig(A.T@A) # eigenvalues and eigenvectors of A.T*A
idx = Mu.argsort()[::-1] # arrange from eigenvalues in decending order largest to smallest
Mu = Mu[idx]
v = v[:,idx]

lamda = Mu # eigenvalues of A*A.T
u = A@v  # eigenvectors of A*A.T

# Normalize the eigenvectors to unit vectors   
norm = np.linalg.norm(u,axis=0)
u = u/norm 

# Calculate the projection-coefficients vectors correponding to the training images
Train_Proj_coef = (A.T@u).T  # the transpose ().T on omega is applied to have each column yi corresponding to an image

# Reconstruction check
Train_Img = Train_img_pixel[:,1] 
Reconstructed_Img = Train_Proj_coef[:,1]@u.T + avg_face # add average image for reconstruction
Reconstruction_Error = np.linalg.norm(Train_Img-Reconstructed_Img)/Size_img
print('reconstruction error:', Reconstruction_Error)

# Store training data
wb = xlsxwriter.Workbook('D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Training data_low_reso.xlsx')
sh1 = wb.add_worksheet('Avg Face')  
sh1.write_column(0,0,avg_face)
sh2 = wb.add_worksheet('Eigen Vectors')  
for Count in range(0,u.shape[1]):
    sh2.write_column(0,Count,u[:,Count])    
sh3 = wb.add_worksheet('Projection-coefficients vectors')  
for Count in range(0,Train_Proj_coef.shape[1]):
    sh3.write_column(0,Count,Train_Proj_coef[:,Count])
wb.close()

# # Eigenfaces corresponding to the ten largest eigenvectors 
# for Count in range(0,10):
#     face_img = Image.new(img.mode,img.size)
#     face_img.putdata(np.int_(255*(u[:,Count]-np.min(u[:,Count]))/(np.max(u[:,Count])-np.min(u[:,Count]))))
#     save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
#     name = 'EigenFace'+str(Count+1)
#     filepath = save_path + name + '.png'
#     face_img.save(filepath, format="png")
#     face_img.show()

# # Eigenfaces corresponding to the ten smallest eigenvectors 
# for Count in range(0,10):
#     face_img = Image.new(img.mode,img.size)
#     face_img.putdata(np.int_(255*(u[:,Count-10]-np.min(u[:,Count-10]))/(np.max(u[:,Count-10])-np.min(u[:,Count-10]))))
#     save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
#     name = 'EigenFace'+str(Count-10)
#     filepath = save_path + name + '.png'
#     face_img.save(filepath, format="png")
#     face_img.show()

# Test images with Training images
# Use following different T %

T = 0.8 # predetermined threshold, top eigenvectors preserving 80% of information
# T = 0.9
# T = 0.95

r = (np.rint(np.linspace(1,50,25))).astype(int) # rank r from 1 to 50
Correct_match = np.zeros(len(r))
Performance = np.zeros(len(r))

# Number of eigenvectors that preserves at least T = 80% of the information
threshold = 0
Num_of_Eigvector = 0 
while threshold <= T:
    Num_of_Eigvector = Num_of_Eigvector+1
    threshold = np.sum(lamda[0:Num_of_Eigvector])/np.sum(lamda)
    
# read test images
Test_img_total = 1196
Test_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fb_L\*.pgm' 
Test_img_name = []
Test_img_pixel = np.zeros((Size_img,Test_img_total))
Count = 0 
for filename in glob.glob(Test_img_path): 
    img=Image.open(filename)
    Test_img_name.append(filename)
    Test_img_pixel[:,Count] = img.getdata()
    Count = Count+1
for Count in range(0,Test_img_total):
    Test_img_name[Count] = os.path.basename(Test_img_name[Count]) # extraxct the file name from the path 

# Compare the test image to the list of training images
Train_img_name2 = []
Count = 0 
for filename in glob.glob(Train_img_path): 
    Train_img_name2.append(filename)
    Count = Count+1
for Count in range(0,Train_img_total):
    Train_img_name2[Count] = os.path.basename(Train_img_name2[Count]) # extraxct the file name from the path 
    Train_img_name2[Count] = Train_img_name2[Count].replace('fa','fb') 

# counter for plotting the matched/mismatched images
train_test = 1  
for Count in range(0,len(r)):
    for Count_2 in range(0,Test_img_total):
        Test_img_pixel_Centered = Test_img_pixel[:,Count_2]-avg_face # subtracted test image from avg_face(from training data)
        Test_Proj_coef = Test_img_pixel_Centered@u[:,0:Num_of_Eigvector]

        # Calculate Mahalanobis Distance between current test image and each training image

        Match_distance = np.zeros(Train_img_total) 
        for Count_3 in range(0,Train_img_total):
            for Count_4 in range(0,Num_of_Eigvector):
                Match_distance[Count_3] += (Test_Proj_coef[Count_4]-Train_Proj_coef[Count_4,Count_3])**2/lamda[Count_4]
        Closed_match_index = np.argsort(Match_distance)
        TestImageName = os.path.basename(Test_img_name[Count_2]) # name of the test image

        # Run if or else part's plot to show correctly matched and incorrectly matched image 
        if TestImageName in list(np.array(Train_img_name2)[list(Closed_match_index[:r[Count]])]):
            Correct_match[Count] += 1

            # # plot results for the correctly matched 3 test images from training image
            
            # # plot query/test image
            # face_img = Image.new(img.mode,img.size)
            # face_img.putdata(Test_img_pixel[:,Count_2])
            # save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
            # name = 'QueryMat'+str(train_test)+'_'+str(T*100)+'%'
            # filepath = save_path + name + '.png'
            # face_img.save(filepath, format="png")
            # face_img.show()

            # # plot gallery/training image
            # face_img = Image.new(img.mode,img.size)
            # face_img.putdata(Train_img_pixel[:,Closed_match_index[0]])
            # save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
            # name = 'TrainingMat'+str(train_test)+'_'+str(T*100)+'%'
            # filepath = save_path + name + '.png'
            # face_img.save(filepath, format="png")
            # face_img.show()
            # train_test = train_test + 1
            # if train_test>3:
            #     break
    #     else:
    #             # plot results for the incorrectly matched 3 test images from training image
    #             # plot query/test image
    #         face_img = Image.new(img.mode,img.size)
    #         face_img.putdata(Test_img_pixel[:,Count_2])
    #         save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
    #         name = 'QueryMismat'+str(train_test)+'_'+str(T*100)+'%'
    #         filepath = save_path + name + '.png'
    #         face_img.save(filepath, format="png")
    #         face_img.show()
    #         # plot gallery/raining image
    #         face_img = Image.new(img.mode,img.size)
    #         face_img.putdata(Train_img_pixel[:,Closed_match_index[0]]) # Best match from the training set
    #         save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
    #         name = 'TrainingMismat'+str(train_test)+'_'+str(T*100)+'%'
    #         filepath = save_path + name + '.png'
    #         face_img.save(filepath, format="png")
    #         face_img.show()
    #         train_test = train_test + 1
    #         if train_test>3:
    #             break
    # break     
    Performance[Count] = Correct_match[Count]/Test_img_total

    
# Plot the CMC curve
fig, ax = plt.subplots()
plt.plot(r,Performance,'r-',markersize=3,label='T = '+str(T*100)+'%')
plt.ylim([0.5,1])
plt.xlim([0,50])
plt.xlabel("Rank")
plt.ylabel("Performance")
plt.legend(loc ="upper left",fontsize = 12, markerscale = .5)
plt.show()
