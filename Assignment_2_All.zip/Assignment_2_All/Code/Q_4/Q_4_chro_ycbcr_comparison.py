import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# RGB to Chromatic
def rgb_to_chromatic(image):
    total = np.sum(image, axis=2, dtype=np.float32)
    total[total == 0] = 1  # Avoid division by zero
    r_chromatic = image[:,:,0] / total
    g_chromatic = image[:,:,1] / total
    return r_chromatic, g_chromatic

# RGB to YCbCr
def rgb_to_ycbcr(image):
    r, g, b = image[:,:,0], image[:,:,1], image[:,:,2]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = -0.169 * r - 0.332 * g + 0.500 * b
    cr = 0.500 * r - 0.419 * g - 0.081 * b
    return y,cb, cr

def load_image(filename):
    image = Image.open(filename)
    image = np.array(image)
    return image

def calculate_likelihood(pixel, mean, covariance):
    # Calculate the probability density function of a multivariate Gaussian distribution
    diff = pixel - mean
    exponent = np.exp(-0.5 * np.sum(np.dot(diff, np.linalg.inv(covariance)) * diff, axis=1))
    det = np.linalg.det(covariance)
    constant = 1 / (2 * np.pi * np.sqrt(det))
    likelihood = constant * exponent
    return likelihood

# Skin color model for Chromatic
def test_skin_color_model_chromatic(test_image_path, reference_image_test_path, skin_pixels_mask, rg_train, yb_train, mean, covariance):
    # Load test image
    test_image = load_image(test_image_path)
    reference_image_test = load_image(reference_image_test_path)

    # Convert test image to chromatic color space
    rg_test, yb_test = rgb_to_chromatic(test_image)

    # Test the skin color model
    thresholds_chromatic = np.linspace(0, 1/(2*np.pi*np.sqrt(np.linalg.det(covariance))), 20)
    false_positive_rates = []
    false_negative_rates = []
    equal_error_rate = 1.0

    for threshold_chromatic in thresholds_chromatic:
        likelihoods = calculate_likelihood(np.column_stack((rg_test.flatten(), yb_test.flatten())), mean, covariance)
        predictions = likelihoods > threshold_chromatic

        true_positives = np.sum(predictions[skin_pixels_mask.flatten()])
        false_positives = np.sum(predictions[np.logical_not(skin_pixels_mask.flatten())])
        true_negatives = np.sum(np.logical_not(predictions[np.logical_not(skin_pixels_mask.flatten())]))
        false_negatives = np.sum(np.logical_not(predictions[skin_pixels_mask.flatten()]))

        false_positive_rate = false_positives / (false_positives + true_negatives)
        false_negative_rate = false_negatives / (false_negatives + true_positives)

        false_positive_rates.append(false_positive_rate)
        false_negative_rates.append(false_negative_rate)

        # Calculate Equal Error Rate (ERR) threshold
        if abs(false_positive_rate - false_negative_rate) < equal_error_rate:
            equal_error_rate = abs(false_positive_rate - false_negative_rate)
            equal_error_threshold = threshold_chromatic

    return false_positive_rates, false_negative_rates, thresholds_chromatic

# Skin color model for YCbCr
def test_skin_color_model_ycbcr(test_image_path, reference_image_test_path, skin_pixels_mask, cb_train, cr_train, mean, covariance):
    # Load test image
    test_image = load_image(test_image_path)
    reference_image_test = load_image(reference_image_test_path)

    # Convert test image to YCbCr color space
    _, cb_test, cr_test = rgb_to_ycbcr(test_image)

    # Test the skin color model
    thresholds_ycbcr = np.linspace(0, 1/(2*np.pi*np.sqrt(np.linalg.det(covariance))), 20)
    false_positive_rates = []
    false_negative_rates = []
    equal_error_rate = 1.0

    for threshold_ycbcr in thresholds_ycbcr:
        likelihoods = calculate_likelihood(np.column_stack((cb_test.flatten(), cr_test.flatten())), mean, covariance)
        predictions = likelihoods > threshold_ycbcr

        true_positives = np.sum(predictions[skin_pixels_mask.flatten()])
        false_positives = np.sum(predictions[np.logical_not(skin_pixels_mask.flatten())])
        true_negatives = np.sum(np.logical_not(predictions[np.logical_not(skin_pixels_mask.flatten())]))
        false_negatives = np.sum(np.logical_not(predictions[skin_pixels_mask.flatten()]))

        false_positive_rate = false_positives / (false_positives + true_negatives)
        false_negative_rate = false_negatives / (false_negatives + true_positives)

        false_positive_rates.append(false_positive_rate)
        false_negative_rates.append(false_negative_rate)

        # Calculate Equal Error Rate (ERR) threshold
        if abs(false_positive_rate - false_negative_rate) < equal_error_rate:
            equal_error_rate = abs(false_positive_rate - false_negative_rate)
            equal_error_threshold = threshold_ycbcr

    return false_positive_rates, false_negative_rates, thresholds_ycbcr

def main():
    # Load training image and reference image
    training_image = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_1.ppm")
    reference_image = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref1.ppm")

    # Extract skin pixels from reference image
    skin_pixels_mask = np.any(reference_image != 0, axis=2)

    # Convert training image to chromatic color space
    rg_train, yb_train = rgb_to_chromatic(training_image)
    y_train, cb_train, cr_train = rgb_to_ycbcr(training_image)

    # Extract skin pixels from training image
    skin_pixels_train_chromatic = np.column_stack((rg_train[skin_pixels_mask], yb_train[skin_pixels_mask]))
    skin_pixels_train_ycbcr = np.column_stack((cb_train[skin_pixels_mask], cr_train[skin_pixels_mask]))

    # Estimate parameters for Gaussian model (mean and covariance)
    mean_chromatic = np.mean(skin_pixels_train_chromatic, axis=0)
    covariance_chromatic = np.cov(skin_pixels_train_chromatic, rowvar=False)

    mean_ycbcr = np.mean(skin_pixels_train_ycbcr, axis=0)
    covariance_ycbcr = np.cov(skin_pixels_train_ycbcr, rowvar=False)

    # Test with Training_3.ppm and ref3.ppm
    fp_rates_chromatic_3, fn_rates_chromatic_3, thresholds_chromatic_3 = test_skin_color_model_chromatic("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_3.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref3.ppm", skin_pixels_mask,  rg_train, yb_train, mean_chromatic, covariance_chromatic)
    fp_rates_ycbcr_3, fn_rates_ycbcr_3, thresholds_ycbcr_3 = test_skin_color_model_ycbcr("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_3.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref3.ppm", skin_pixels_mask, cb_train, cr_train, mean_ycbcr, covariance_ycbcr)

    # Test with Training_6.ppm and ref6.ppm
    fp_rates_chromatic_6, fn_rates_chromatic_6, thresholds_chromatic_6 = test_skin_color_model_chromatic("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_6.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref6.ppm", skin_pixels_mask, rg_train, yb_train, mean_chromatic, covariance_chromatic)
    fp_rates_ycbcr_6, fn_rates_ycbcr_6, thresholds_ycbcr_6 = test_skin_color_model_ycbcr("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_6.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref6.ppm", skin_pixels_mask, cb_train, cr_train, mean_ycbcr, covariance_ycbcr)

    # Plot ROC curves
    plt.figure(figsize=(8, 6))
    plt.plot(fp_rates_chromatic_3, fn_rates_chromatic_3, label='Chromatic (Training_3)')
    plt.plot(fp_rates_chromatic_6, fn_rates_chromatic_6, label='Chromatic (Training_6)')
    plt.plot(fp_rates_ycbcr_3, fn_rates_ycbcr_3, label='YCbCr (Training_3)')
    plt.plot(fp_rates_ycbcr_6, fn_rates_ycbcr_6, label='YCbCr (Training_6)')
    plt.xlabel('False Positive Rate')
    plt.ylabel('False Negative Rate')
    plt.title('ROC Curves Comparison')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()

