from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Create a 5x5 test image
test_image = np.array([
    [10, 20, 30, 40, 50],
    [70, 100, 110, 120, 130],
    [140, 160, 170, 150, 155],
    [125, 135, 145, 155, 165],
    [130, 240, 250, 160, 170]
], dtype=np.uint8)


# Calculate the histogram of 5x5 test image
histogram = np.zeros(256, dtype=int)
for pixel_value in test_image.flatten():
    histogram[pixel_value] += 1


# Calculate the cumulative distribution function (CDF) from the histogram
cdf = np.zeros(256, dtype=int)
cdf[0] = histogram[0]
for i in range(1, 256):
    cdf[i] = cdf[i - 1] + histogram[i]

# # Calculate the cumulative distribution function (CDF) from the histogram
# cdf = np.cumsum(histogram)

# Calculate the total number of pixels in the image
total_pixels = test_image.size

# Map pixel values based on the CDF
equalized_test_image = (cdf[test_image] / total_pixels * 255).astype(np.uint8)


# Plot the original and equalized images side by side
plt.figure(figsize=(10, 10))

plt.subplot(1, 2, 1)
plt.imshow(test_image, cmap='gray', vmin=0, vmax=255)
plt.title('Original Image')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(equalized_test_image, cmap='gray', vmin=0, vmax=255)
plt.title('Equalized test Image')
plt.axis('off')

plt.tight_layout()
plt.show()