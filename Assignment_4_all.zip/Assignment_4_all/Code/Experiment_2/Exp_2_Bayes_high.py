# Use this code for Bayes classifier with High resolution 48_60 data

import numpy as np

# Load data
def load_data(fold_num):
    # Load first 30 eigen-coefficients
    tr_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_48_60\\_trPCA_{fold_num:02d}.txt')[:, :30]
    ts_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_48_60\\_tsPCA_{fold_num:02d}.txt')[:, :30]

    # Load class labels
    T_tr = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_48_60\\_TtrPCA_{fold_num:02d}.txt')
    T_ts = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_48_60\\_TtsPCA_{fold_num:02d}.txt')

    return tr_pca, T_tr, ts_pca, T_ts

# Train Bayes classifier
def train_bayes(tr_pca, T_tr):
    # Separate data by class
    male_data = tr_pca[T_tr == 1]
    female_data = tr_pca[T_tr == 2]

    # Calculate class means
    male_mean = np.mean(male_data, axis=0)
    female_mean = np.mean(female_data, axis=0)

    # Calculate class covariances (assuming diagonal covariance matrix)
    male_cov = np.diag(np.var(male_data, axis=0))
    female_cov = np.diag(np.var(female_data, axis=0))

    return male_mean, male_cov, female_mean, female_cov

# Calculate Mahalanobis distance
def mahalanobis_distance(sample, mean, cov):
    diff = sample - mean
    inv_cov = np.linalg.inv(cov)
    md = np.sqrt(np.dot(np.dot(diff, inv_cov), diff))
    return md

# Classify using Bayes classifier
def classify_bayes(ts_pca, male_mean, male_cov, female_mean, female_cov):
    # Initialize predictions array
    predictions = np.zeros(len(ts_pca))

    # Classify each test sample
    for i, sample in enumerate(ts_pca):
        # Calculate Mahalanobis distances
        male_distance = mahalanobis_distance(sample, male_mean, male_cov)
        female_distance = mahalanobis_distance(sample, female_mean, female_cov)

        # Classify based on minimum distance
        if male_distance < female_distance:
            predictions[i] = 1  # Male
        else:
            predictions[i] = 2  # Female

    return predictions

# Calculate accuracy
def calculate_accuracy(true_labels, predicted_labels):
    num_correct = np.sum(true_labels == predicted_labels)
    total_instances = len(true_labels)
    accuracy = (num_correct / total_instances) * 100
    return accuracy

# Calculate classification error
def calculate_classification_error(true_labels, predicted_labels):
    num_errors = np.sum(true_labels != predicted_labels)
    total_instances = len(true_labels)
    error_rate = num_errors / total_instances
    classification_error = error_rate * 100
    return classification_error

# Main function
def main():
    # Number of folds
    num_folds = 3
    total_classification_error = 0
    accuracy_per_fold = []
    classification_error_per_fold = []

    # Iterate over folds
    for fold_num in range(1, num_folds + 1):
        # Load data for fold
        tr_pca, T_tr, ts_pca, T_ts = load_data(fold_num)

        # Train Bayes classifier
        male_mean, male_cov, female_mean, female_cov = train_bayes(tr_pca, T_tr)

        # Classify test set
        predictions = classify_bayes(ts_pca, male_mean, male_cov, female_mean, female_cov)

        # Calculate accuracy
        accuracy = calculate_accuracy(T_ts, predictions)
        accuracy_per_fold.append(accuracy)

        # Calculate classification error
        classification_error = calculate_classification_error(T_ts, predictions)
        total_classification_error += classification_error

        # Store the classification error for the fold
        classification_error_per_fold.append(classification_error)

        print(f'Fold {fold_num}: Classification Error (Bayes) = {classification_error:.2f}%')

    # Print accuracy of each fold at the end
    for fold_num, accuracy in enumerate(accuracy_per_fold, start=1):
        print(f'Fold {fold_num}: Accuracy (Bayes 48*60) = {accuracy:.2f}%')
        
    # Print classification error of each fold at the end
    for fold_num, error in enumerate(classification_error_per_fold, start=1):
        print(f'Fold {fold_num}: Classification Error (Bayes 48*60) = {error:.2f}%')

    # Calculate average classification error
    average_classification_error = total_classification_error / num_folds
    print(f'Average Classification Error (Bayes 48*60) = {average_classification_error:.2f}%')

if __name__ == "__main__":
    main()
