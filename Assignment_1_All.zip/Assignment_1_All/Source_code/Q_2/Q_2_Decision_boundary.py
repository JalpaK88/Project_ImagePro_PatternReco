import numpy as np
import matplotlib.pyplot as plt

def ranf(m):
    return m * np.random.rand()

def box_muller_transform(mu, sigma):
    u1 = ranf(1)
    u2 = ranf(1)
    z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
    z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)
    return z0 * np.sqrt(sigma) + mu

def generate_2d_gaussian_samples(mu, sigma, num_samples):
    samples = []
    for _ in range(num_samples):
        x, y = box_muller_transform(mu[0], sigma[0, 0]), box_muller_transform(mu[1], sigma[1, 1])
        samples.append([x, y])
    return np.array(samples)

# Parameters for data set B
mu1 = np.array([1, 1])
sigma1 = np.array([[1, 0], [0, 1]])

mu2 = np.array([4, 4])
sigma2 = np.array([[4, 0], [0, 8]])

num_samples_class1 = 60000
num_samples_class2 = 140000

# Generate data set B
class1_data = generate_2d_gaussian_samples(mu1, sigma1, num_samples_class1)
class2_data = generate_2d_gaussian_samples(mu2, sigma2, num_samples_class2)

# Calculate prior probabilities
prior_prob_class1 = num_samples_class1 / (num_samples_class1 + num_samples_class2)
prior_prob_class2 = num_samples_class2 / (num_samples_class1 + num_samples_class2)

# Define the discriminant function Case_III
def discriminant_function(x, sigma_inv, mu, sigma_det, prior_prob):
    # Calculate Wi
    W_i = -0.5 * sigma_inv
    # Calculate wi
    w_i = np.dot(sigma_inv, mu)
    # Calculate wi0
    w_i0 = -0.5 * np.dot(mu.T, np.dot(sigma_inv, mu)) - 0.5 * np.log(sigma_det) + np.log(prior_prob)
    
    # Calculate quadratic part
    quadratic_part = np.dot(np.dot(x.T, W_i), x)
    # Calculate linear part
    linear_part = np.dot(w_i.T, x)
    # Add constant term
    discriminant_val = quadratic_part + linear_part + w_i0
    
    return discriminant_val

# Compute sigma inverse and determinant for both classes
sigma_inv_class1 = np.linalg.inv(sigma1)
sigma_det_class1 = np.linalg.det(sigma1)
sigma_inv_class2 = np.linalg.inv(sigma2)
sigma_det_class2 = np.linalg.det(sigma2)

# Bayes classification
misclassifications = 0
class1_correct = []
class2_correct = []
class1_incorrect = []
class2_incorrect = []

for sample in class1_data:
    discriminant_val_class1 = discriminant_function(sample, sigma_inv_class1, mu1, sigma_det_class1, prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, sigma_inv_class2, mu2, sigma_det_class2, prior_prob_class2)
    if discriminant_val_class1 < discriminant_val_class2:
        misclassifications += 1
        class1_incorrect.append(sample)
    else:
        class1_correct.append(sample)

for sample in class2_data:
    discriminant_val_class1 = discriminant_function(sample, sigma_inv_class1, mu1, sigma_det_class1, prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, sigma_inv_class2, mu2, sigma_det_class2, prior_prob_class2)
    if discriminant_val_class1 > discriminant_val_class2:
        misclassifications += 1
        class2_incorrect.append(sample)
    else:
        class2_correct.append(sample)

error_rate = misclassifications / (num_samples_class1 + num_samples_class2)
Percentage_error_rate = error_rate * 100
print("Error rate:", error_rate)
print("Percentage Error rate:", Percentage_error_rate)


# Convert lists to numpy arrays
class1_correct = np.array(class1_correct)
class1_incorrect = np.array(class1_incorrect)
class2_correct = np.array(class2_correct)
class2_incorrect = np.array(class2_incorrect)

# Plotting
plt.figure(figsize=(8, 6))

# # Plot samples from class 1
# plt.scatter(class1_data[:, 0], class1_data[:, 1], c='blue', label='Class 1')

# # Plot samples from class 2
# plt.scatter(class2_data[:, 0], class2_data[:, 1], c='red', label='Class 2')

# Plot samples from class 1
plt.scatter(class1_correct[:, 0], class1_correct[:, 1], c='blue', label='Class 1 (Correctly Classified)')
plt.scatter(class1_incorrect[:, 0], class1_incorrect[:, 1], c='lightblue', label='Class 1 (Misclassified)')

# Plot samples from class 2
plt.scatter(class2_correct[:, 0], class2_correct[:, 1], c='red', label='Class 2 (Correctly Classified)')
plt.scatter(class2_incorrect[:, 0], class2_incorrect[:, 1], c='lightcoral', label='Class 2 (Misclassified)')

# Plot Bayes decision boundary
# Calculate decision boundary
W_diff = -0.5 * np.linalg.inv(sigma1) - (-0.5) * np.linalg.inv(sigma2)
w_diff = np.dot(np.linalg.inv(sigma1), mu1) - np.dot(np.linalg.inv(sigma2), mu2)
w_diff_0 = -0.5 * np.dot(mu1.T, np.dot(np.linalg.inv(sigma1), mu1)) + 0.5 * np.dot(mu2.T, np.dot(np.linalg.inv(sigma2), mu2)) - 0.5 * np.log(np.linalg.det(sigma1) / np.linalg.det(sigma2)) + np.log(prior_prob_class1 / prior_prob_class2)

# # Plot decision boundary
# x_range = np.linspace(-1, 7, 400)
# y_range = np.linspace(-1, 7, 400)
# X, Y = np.meshgrid(x_range, y_range)
# Z = np.zeros(X.shape)
# for i in range(X.shape[0]):
#     for j in range(X.shape[1]):
#         x_vec = np.array([X[i, j], Y[i, j]])
#         Z[i, j] = np.dot(np.dot(x_vec.T, W_diff), x_vec) + np.dot(w_diff.T, x_vec) + w_diff_0
# plt.contour(X, Y, Z, levels=[0], colors='green', linestyles='--', label='Bayes Decision Boundary')


# Define the range for the meshgrid
x_min, x_max = min(class1_data[:,0].min(), class2_data[:,0].min()) - 1, max(class1_data[:,0].max(), class2_data[:,0].max()) + 1
y_min, y_max = min(class1_data[:,1].min(), class2_data[:,1].min()) - 1, max(class1_data[:,1].max(), class2_data[:,1].max()) + 1

# Create meshgrid
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))

# Calculate decision boundary for each point in meshgrid
Z = np.zeros(xx.shape)
for i in range(xx.shape[0]):
    for j in range(xx.shape[1]):
        # point = np.array([xx[i, j], yy[i, j]])  
        x_vec = np.array([xx[i, j], yy[i, j]])
        Z[i, j] = np.dot(np.dot(x_vec.T, W_diff), x_vec) + np.dot(w_diff.T, x_vec) + w_diff_0

# Plot decision boundary
plt.contour(xx, yy, Z, levels=[0], colors='green', linestyles='solid', label='Bayes Decision Boundary')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Bayes Decision Boundary and Samples from Data Set B')
plt.legend()
# plt.grid(True)
plt.show()
