import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# RGB to YCbCr
def rgb_to_ycbcr(image):
    r, g, b = image[:,:,0], image[:,:,1], image[:,:,2]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = -0.169 * r - 0.332 * g + 0.500 * b
    cr = 0.500 * r - 0.419 * g - 0.081 * b
    return y, cb, cr

def load_image(filename):
    image = Image.open(filename)
    image = np.array(image)
    return image

# Calculate the probability density function of a multivariate Gaussian distribution
def calculate_likelihood(pixel, mean, covariance): 
    diff = pixel - mean
    exponent = np.exp(-0.5 * np.sum(np.dot(diff, np.linalg.inv(covariance)) * diff, axis=1))
    det = np.linalg.det(covariance)
    constant = 1 / (2 * np.pi * np.sqrt(det))
    likelihood = constant * exponent
    return likelihood

def test_skin_color_model(test_image_path, reference_image_test_path, skin_pixels_mask, cb_train, cr_train, mean, covariance):
    # Load test image
    test_image = load_image(test_image_path)
    reference_image_test = load_image(reference_image_test_path)

    # Convert test image to YCbCr color space
    _, cb_test, cr_test = rgb_to_ycbcr(test_image)

    # Test the skin color model using different thresholds
    thresholds = np.linspace(0, 1/(2*np.pi*np.sqrt(np.linalg.det(covariance))), 20)
    false_positive_rates = []
    false_negative_rates = []
    equal_error_rate = 1.0

    for threshold in thresholds:
        likelihoods = calculate_likelihood(np.column_stack((cb_test.flatten(), cr_test.flatten())), mean, covariance)
        predictions = likelihoods > threshold

        true_positives = np.sum(predictions[skin_pixels_mask.flatten()])
        false_positives = np.sum(predictions[np.logical_not(skin_pixels_mask.flatten())])
        true_negatives = np.sum(np.logical_not(predictions[np.logical_not(skin_pixels_mask.flatten())]))
        false_negatives = np.sum(np.logical_not(predictions[skin_pixels_mask.flatten()]))

        false_positive_rate = false_positives / (false_positives + true_negatives)
        false_negative_rate = false_negatives / (false_negatives + true_positives)

        false_positive_rates.append(false_positive_rate)
        false_negative_rates.append(false_negative_rate)

        # Calculate Equal Error Rate (ERR) threshold
        if abs(false_positive_rate - false_negative_rate) < equal_error_rate:
            equal_error_rate = abs(false_positive_rate - false_negative_rate)
            equal_error_threshold = threshold

    # Classification results using ERR threshold
    likelihoods_err = calculate_likelihood(np.column_stack((cb_test.flatten(), cr_test.flatten())), mean, covariance)
    predictions_err = likelihoods_err > equal_error_threshold

    # Create classified image
    classified_image = np.ones_like(test_image, dtype=np.uint8) * 255  # Initialize with white (non-skin)
    classified_image[predictions_err.reshape(test_image.shape[:2])] = test_image[predictions_err.reshape(test_image.shape[:2])]

    return false_positive_rates, false_negative_rates, thresholds, classified_image, reference_image_test

def main():
    # Load training image and reference image
    # training_image = load_image("Training_1.ppm")
    # reference_image = load_image("_ref1.ppm")

    training_image = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_1.ppm")
    reference_image = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref1.ppm")

    training_image_3 = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_3.ppm")
    reference_image_3 = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref3.ppm")

    training_image_6 = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_6.ppm")
    reference_image_6 = load_image("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref6.ppm")

    # Extract skin pixels from reference image
    skin_pixels_mask = np.any(reference_image != 0, axis=2)

    # Convert training image to YCbCr color space
    y_train, cb_train, cr_train = rgb_to_ycbcr(training_image)

    # Extract skin pixels from training image
    skin_pixels_train = np.column_stack((cb_train[skin_pixels_mask], cr_train[skin_pixels_mask]))

    # Estimate parameters for Gaussian model (mean and covariance)
    mean = np.mean(skin_pixels_train, axis=0)
    covariance = np.cov(skin_pixels_train, rowvar=False)

    # Test with Training_3.ppm and ref3.ppm
    fp_rates_3, fn_rates_3, thresholds_3, classified_image_3, reference_image_test_3 = test_skin_color_model("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_3.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref3.ppm", skin_pixels_mask, cb_train, cr_train, mean, covariance)

    # Test with Training_6.ppm and ref6.ppm
    fp_rates_6, fn_rates_6, thresholds_6, classified_image_6, reference_image_test_6 = test_skin_color_model("D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\Training_6.ppm", "D:\Program_jalpa\Pattern_recognition\Assignment_2\P2_Data\Data_Prog2\_ref6.ppm", skin_pixels_mask, cb_train, cr_train, mean, covariance)

    # Find the threshold corresponding to the Equal Error Rate (ERR)
    equal_error_rate_index_3 = np.argmin(np.abs(np.array(fp_rates_3) - np.array(fn_rates_3)))
    equal_error_rate_threshold_3 = thresholds_3[equal_error_rate_index_3]
    equal_error_rate_index_6 = np.argmin(np.abs(np.array(fp_rates_6) - np.array(fn_rates_6)))
    equal_error_rate_threshold_6 = thresholds_6[equal_error_rate_index_6]

    # Generate ROC plots
    plt.figure(figsize=(10, 5))

    # Generate ROC Curve - 1
    plt.subplot(1, 2, 1)
    plt.plot(fp_rates_3, fn_rates_3, label='Training_3')
    plt.plot(fp_rates_6, fn_rates_6, label='Training_6')
    plt.xlabel('False Positive Rate')
    plt.ylabel('False Negative Rate')
    plt.title('ROC Curve-1')
    plt.legend()

    # Calculate error rates for threshold values
    error_rates_3 = np.abs(np.array(fp_rates_3) - np.array(fn_rates_3))
    error_rates_6 = np.abs(np.array(fp_rates_6) - np.array(fn_rates_6))

    # Plot ROC Curve - 2
    plt.subplot(1, 2, 2)
    plt.plot(thresholds_3, error_rates_3, label='Error Rate 3')
    plt.plot(thresholds_6, error_rates_6, label='Error Rate 6')
    plt.xlabel('Threshold')
    plt.ylabel('Error Rate')
    plt.title('ROC Curve-2')
    plt.legend()

    # Display input training image
    plt.figure(figsize=(10, 5))
    
    # Generate sub plots
    plt.subplot(1, 2, 1)
    plt.imshow(training_image)
    plt.title('Training Image (Training_1)')
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(reference_image)
    plt.title('Reference Image (_ref_1)')
    plt.axis('off')

    # Display classified images
    fig, axes = plt.subplots(3, 2, figsize=(10, 8))

    axes[0, 0].imshow(training_image_3)
    axes[0, 0].set_title('Test Image (Training_3)')
    axes[0, 0].axis('off')

    axes[0, 1].imshow(training_image_6)
    axes[0, 1].set_title('Test Image (Training_6)')
    axes[0, 1].axis('off')

    axes[1, 0].imshow(reference_image_test_3)
    axes[1, 0].set_title('Reference Image (_ref_3)')
    axes[1, 0].axis('off')

    axes[1, 1].imshow(reference_image_test_6)
    axes[1, 1].set_title('Reference Image (_ref_6)')
    axes[1, 1].axis('off')

    axes[2, 0].imshow(classified_image_3)
    axes[2, 0].set_title('Classified Image (Training_3)')
    axes[2, 0].axis('off')

    axes[2, 1].imshow(classified_image_6)
    axes[2, 1].set_title('Classified Image (Training_6)')
    axes[2, 1].axis('off')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
