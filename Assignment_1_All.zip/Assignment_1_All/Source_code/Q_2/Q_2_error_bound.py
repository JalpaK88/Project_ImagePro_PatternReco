import numpy as np

# Parameters for data set A
mu1 = np.array([1, 1])
sigma1 = np.array([[1, 0], [0, 1]])

mu2 = np.array([4, 4])
sigma2 = np.array([[4, 0], [0, 8]])

# Prior probabilities
prior_prob_class1 = 60000 / (60000 + 140000)
prior_prob_class2 = 140000 / (60000 + 140000)

# # Bhattacharyya bound calculation
# sigma_sum = (sigma1 + sigma2) / 2
# mu_diff = mu2 - mu1
# # mu_diff = mu1 - mu2
# cov_det_product = np.sqrt(np.linalg.det(sigma1)) * np.sqrt(np.linalg.det(sigma2))
# # cov_det_product = np.sqrt(np.linalg.det(sigma1) * np.linalg.det(sigma2))
# cov_sum_det = np.linalg.det(sigma_sum)

# k_half = 0.125 * np.dot(mu_diff.T, np.dot(np.linalg.inv(sigma_sum), mu_diff)) + 0.5 * np.log(cov_sum_det / cov_det_product)
# bhattacharyya_bound = np.sqrt(prior_prob_class1 * prior_prob_class2) * np.exp(-k_half)

# Bhattacharyya bound calculation
beta = 0.5
beta_diff = 0.5 * np.dot(beta, 1-beta)
mu_diff = mu1 - mu2
# sigma_sum = 0.5 * (sigma1+sigma2)
sigma_sum = np.dot(1-beta,sigma1) + np.dot(beta,sigma2)
cov_sum_det = np.linalg.det(sigma_sum)
cov_det_product = np.sqrt(np.linalg.det(sigma1)) * np.sqrt(np.linalg.det(sigma2))

k_beta = beta_diff * np.dot(mu_diff.T, np.dot(np.linalg.inv(sigma_sum), mu_diff)) + 0.5 * np.log(cov_sum_det / cov_det_product)
bhattacharyya_bound = np.sqrt(prior_prob_class1) * np.sqrt(prior_prob_class2) * np.exp(-k_beta)
percentage_error_bound = bhattacharyya_bound * 100

# print(beta_diff)
# print(mu_diff)
# print(mu_diff.T)
# print(sigma_sum)
# print(cov_sum_det)
# print(cov_det_product)
# print(np.dot(mu_diff.T, np.dot(np.linalg.inv(sigma_sum), mu_diff)))
# print(k_beta)
# print(k_half)
print("Bhattacharyya bound for the probability of error for Data set B:", bhattacharyya_bound)
print("Percentage Bhattacharyya error bound:", percentage_error_bound)