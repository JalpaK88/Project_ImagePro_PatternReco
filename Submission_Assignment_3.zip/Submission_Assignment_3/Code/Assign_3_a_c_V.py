# Use this code for Experimetn a-V and c-V CMC curves using different T = 80%, 90%, 95% values for High and low resolution.

from PIL import Image
import glob
import numpy as np
import matplotlib.pyplot as plt
import os  

# Training of images
# Read training images
Train_img_total = 1204

# size of each image in dataset
Size_img = 2880 # use this for high resolution 48 * 60
# Size_img = 320 # use this for low resolution 16 * 20

# Use this path for high resolution
Train_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fa_H\*.pgm'

# Use this path for low resolution
# Train_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fa_L\*.pgm'

Train_img_name = []
Train_img_name = []
Train_img_pixel = np.zeros((Size_img,Train_img_total))
Count = 0 
for filename in glob.glob(Train_img_path): 
    img = Image.open(filename)
    Train_img_name.append(filename)
    Train_img_pixel[:,Count] = img.getdata()
    Count = Count + 1
for Count in range(0,Train_img_total):
    Train_img_name[Count] = os.path.basename(Train_img_name[Count]) # extraxct the file name from the path 
    
# Calculate the average face
avg_face = Train_img_pixel.sum(axis=1)/Train_img_total

# Show and save the average face
avg_face_img = Image.new(img.mode,img.size)
avg_face_img.putdata(np.int_(255*(avg_face-np.min(avg_face))/(np.max(avg_face)-np.min(avg_face))))
save_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\Jalpa'
name = 'Avg_Face'
filepath = save_path + name + '.png'
avg_face_img.save(filepath, format="png")
# avg_face_img.show()

# subtract the average face from the training faces, calculated phi
A = (Train_img_pixel.T-avg_face).T

# Calculate eigenvectors and eigenvalues
Mu,v = np.linalg.eig(A.T@A) # eigenvalues and eigenvectors of A.T*A
idx = Mu.argsort()[::-1] # arrange from eigenvalues in decending order largest to smallest
Mu = Mu[idx]
v = v[:,idx]

lamda = Mu # eigenvalues of A*A.T
u = A@v  # eigenvectors of A*A.T

# Normalize the eigenvectors to unit vectors   
norm = np.linalg.norm(u,axis=0)
u = u/norm 

# Calculate the projection-coefficients omega vectors correponding to the training images
Train_Proj_coef = (A.T@u).T  # the transpose ().T on omega is applied to have each column yi corresponding to an image


# Test images with Training images
# Initialize parameters
T = np.array([0.8,0.9,0.95]) # different threshold 80%, 90%, 95%, top eigenvectors preserving the information
r = (np.rint(np.linspace(1,50,25))).astype(int) # rank r from 1 to 50
Correct_match = np.zeros(len(r))
Correct_match = np.zeros([len(T),len(r)])
Performance = np.zeros([len(T),len(r)])

for t in range(0,len(T)):

    # Number of eigenvectors that preserves at least different T% of the information
    threshold = 0
    Num_of_Eigvector = 0 
    while threshold <= T[t]:
        Num_of_Eigvector = Num_of_Eigvector+1
        threshold = np.sum(lamda[0:Num_of_Eigvector])/np.sum(lamda)

    # read images
    Test_img_total = 1196

    # Use this path for High resolution
    Test_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fb_H\*.pgm' 

    # Use this path for low resolution
    # Test_img_path = 'D:\Program_jalpa\Pattern_recognition\Assignment_3\Faces_FA_FB\_fb_L\*.pgm'
     
    Test_img_name = []
    Test_img_pixel = np.zeros((Size_img,Test_img_total))
    Count = 0 
    for filename in glob.glob(Test_img_path): 
        img = Image.open(filename)
        Test_img_name.append(filename)
        Test_img_pixel[:,Count] = img.getdata()
        Count = Count + 1
    for Count in range(0,Test_img_total):
        Test_img_name[Count] = os.path.basename(Test_img_name[Count]) # extraxct the file name from the path 

    # Compare the test image to the list of training images
    Train_img_name2 = []
    Count = 0 
    for filename in glob.glob(Train_img_path): 
        Train_img_name2.append(filename)
        Count = Count + 1
    for Count in range(0,Train_img_total):
        Train_img_name2[Count] = os.path.basename(Train_img_name2[Count]) # extraxct the file name from the path 
        Train_img_name2[Count] = Train_img_name2[Count].replace('fa','fb') 

    # counter for plotting the matched/mismatched images
    train_test = 1    
    for Count in range(0,len(r)):
        for Count_2 in range(0,Test_img_total):
            Test_img_pixel_Centered = Test_img_pixel[:,Count_2]-avg_face # subtracted test image from avg_face(from training data)
            Test_Proj_coef = Test_img_pixel_Centered@u[:,0:Num_of_Eigvector]

            # Calculate Mahalanobis Distance between current test image and each training image
            Match_distance = np.zeros(Train_img_total)
            for Count_3 in range(0,Train_img_total):
                for Count_4 in range(0,Num_of_Eigvector):
                    Match_distance[Count_3] += (Test_Proj_coef[Count_4]-Train_Proj_coef[Count_4,Count_3])**2/lamda[Count_4]
            Closed_match_index = np.argsort(Match_distance)
            Test_image_name = os.path.basename(Test_img_name[Count_2]) # name of the test image

            # Run if part to plot CMC curve with different threshold T[0],T[1],T[2]
            if Test_image_name in list(np.array(Train_img_name2)[list(Closed_match_index[:r[Count]])]):
                Correct_match[t,Count] += 1           
        Performance[t,Count] = Correct_match[t,Count]/Test_img_total

# Plot the CMC curve
fig, ax = plt.subplots()
plt.plot(r,Performance[0,:],'r-',markersize=3,label='T = '+str(T[0]*100)+'%') # 80% information
plt.plot(r,Performance[1,:],'g-',markersize=3,label='T = '+str(T[1]*100)+'%') # 90% information
plt.plot(r,Performance[2,:],'b-',markersize=3,label='T = '+str(T[2]*100)+'%') # 95% information
plt.ylim([0.5,1])
plt.xlim([0,50])
plt.xlabel("Rank")
plt.ylabel("Performance")
plt.legend(loc ="upper left",fontsize = 10, markerscale = .5)
plt.show()