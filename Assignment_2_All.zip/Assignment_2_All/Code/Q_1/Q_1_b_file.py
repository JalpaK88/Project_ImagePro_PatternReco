# Note: samples of class 1 and 2 data extracted from generated_samples.npz file and experiment with different percentage of data. 
import numpy as np

def ranf(m):
    return m * np.random.rand()

def box_muller_transform(mu, sigma):
    u1 = ranf(1)
    u2 = ranf(1)
    z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
    z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)
    return z0 * np.sqrt(sigma) + mu

def generate_2d_gaussian_samples(mu, sigma, num_samples):
    samples = []
    for _ in range(num_samples):
        x, y = box_muller_transform(mu[0], sigma[0, 0]), box_muller_transform(mu[1], sigma[1, 1])
        samples.append([x, y])
    return np.array(samples)

# Load generated samples from file
data = np.load("D:\Program_jalpa\Pattern_recognition\Assignment_2\generated_samples.npz")
class1_data = data['class1_data']
class2_data = data['class2_data']

# Percentage of training data to be used
percentages = [0.0001, 0.001, 0.01, 0.1]

# Number of samples for each class
num_samples_class1 = len(class1_data)
num_samples_class2 = len(class2_data)

for percentage in percentages:
    print("\nUsing {}% of the samples for parameter estimation:".format(percentage * 100))
    
    # Number of samples to use for parameter estimation
    num_samples_class1_train = int(percentage * num_samples_class1)
    num_samples_class2_train = int(percentage * num_samples_class2)
    
    # Randomly choose samples for training
    class1_train_indices = np.random.choice(num_samples_class1, num_samples_class1_train, replace=False)
    class2_train_indices = np.random.choice(num_samples_class2, num_samples_class2_train, replace=False)
    
    class1_train_data = class1_data[class1_train_indices]
    class2_train_data = class2_data[class2_train_indices]
    
    # Maximum Likelihood estimation of parameters
    estimated_mu1 = np.mean(class1_train_data, axis=0)
    estimated_mu2 = np.mean(class2_train_data, axis=0)

    estimated_sigma1 = np.cov(class1_train_data, rowvar=False)
    estimated_sigma2 = np.cov(class2_train_data, rowvar=False)

    # Calculate prior probabilities
    prior_prob_class1 = num_samples_class1_train / (num_samples_class1_train + num_samples_class2_train)
    prior_prob_class2 = num_samples_class2_train / (num_samples_class1_train + num_samples_class2_train)

    # Define the discriminant function
    def discriminant_function(x, mu, sigma, prior_prob):
        sigma_inv = np.linalg.inv(sigma)
        return -0.5 * np.dot(np.dot((x - mu).T, sigma_inv), (x - mu)) + np.log(prior_prob)

    # Bayes classification
    misclassifications_class1 = 0
    misclassifications_class2 = 0

    for sample in class1_data:
        discriminant_val_class1 = discriminant_function(sample, estimated_mu1, estimated_sigma1, prior_prob_class1)
        discriminant_val_class2 = discriminant_function(sample, estimated_mu2, estimated_sigma2, prior_prob_class2)
        if discriminant_val_class1 < discriminant_val_class2:
            misclassifications_class1 += 1

    for sample in class2_data:
        discriminant_val_class1 = discriminant_function(sample, estimated_mu1, estimated_sigma1, prior_prob_class1)
        discriminant_val_class2 = discriminant_function(sample, estimated_mu2, estimated_sigma2, prior_prob_class2)
        if discriminant_val_class1 > discriminant_val_class2:
            misclassifications_class2 += 1

    # Calculate misclassification rates
    misclassification_rate_class1 = misclassifications_class1 / num_samples_class1
    misclassification_rate_class2 = misclassifications_class2 / num_samples_class2
    total_misclassifications = misclassifications_class1 + misclassifications_class2
    total_misclassification_rate = (misclassifications_class1 + misclassifications_class2) / (num_samples_class1 + num_samples_class2)

    # Percentage of misclassification rates
    misclassification_percentage_class1 = misclassification_rate_class1 * 100
    misclassification_percentage_class2 = misclassification_rate_class2 * 100
    total_misclassification_percentage = total_misclassification_rate * 100

    # Print misclassification rates
    print("Misclassification for Class 1:", misclassifications_class1)
    print("Misclassification for Class 2:", misclassifications_class2)
    print("Total misclassification:", total_misclassifications)

    print("Misclassification rate for Class 1:", misclassification_rate_class1)
    print("Misclassification rate for Class 2:", misclassification_rate_class2)
    print("Total misclassification rate:", total_misclassification_rate)

    print("Percentage of misclassification for class 1:", misclassification_percentage_class1)
    print("Percentage of misclassification for class 2:", misclassification_percentage_class2)
    print("Percentage of misclassification total:", total_misclassification_percentage)
