# Use this code for SVM classifier with polynomial kernel and low resolution 16_20 data

import numpy as np
from libsvm.svmutil import svm_train, svm_predict

# Load data
def load_data(fold_num):
    #Load first 30 eigen-coefficients
    tr_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_trPCA_{fold_num:02d}.txt')[:, :30]
    val_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_valPCA_{fold_num:02d}.txt')[:, :30]
    ts_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_tsPCA_{fold_num:02d}.txt')[:, :30]

    # # Load eigen-coefficients
    # tr_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_trPCA_{fold_num:02d}.txt')
    # val_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_valPCA_{fold_num:02d}.txt')
    # ts_pca = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_tsPCA_{fold_num:02d}.txt')

    # Load class labels
    T_tr = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_TtrPCA_{fold_num:02d}.txt')
    T_val = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_TvalPCA_{fold_num:02d}.txt')
    T_ts = np.loadtxt(f'D:\\Program_jalpa\\Pattern_recognition\\Assignment_4\\GenderDataRowOrder\\_16_20\\_TtsPCA_{fold_num:02d}.txt')

    return tr_pca, T_tr, val_pca, T_val, ts_pca, T_ts

# Scale data between -1 and 1
def scale_data(tr_pca, val_pca, ts_pca):
    def min_max_scaling(data):
        min_val = np.min(data, axis=0)
        max_val = np.max(data, axis=0)
        scaled_data = (data - min_val) / (max_val - min_val)
        scaled_data = scaled_data * 2 - 1
        return scaled_data

    scaled_tr_pca = min_max_scaling(tr_pca)
    scaled_val_pca = min_max_scaling(val_pca)
    scaled_ts_pca = min_max_scaling(ts_pca)
    return scaled_tr_pca, scaled_val_pca, scaled_ts_pca

# Tune SVM parameters with polynomial kernel
def tune_parameters_poly(tr_pca, T_tr, val_pca, T_val):
    best_accuracy = 0
    best_params = ''
    for d in [1, 2, 3]:  # Values for degree parameter
        for c in [0.1, 1, 10, 100]:  # Example values for C parameter
            # Train SVM classifier with polynomial kernel
            model = svm_train(T_tr.tolist(), tr_pca.tolist(), f'-t 1 -d {d} -c {c} -g 1 -r 0') # # gamma g=1 and r represents the c0 set to r=0

            # Predict on validation set
            p_label, p_acc, _ = svm_predict(T_val.tolist(), val_pca.tolist(), model)
            accuracy = p_acc[0]

            # Update best parameters if accuracy is higher
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_params = f'-t 1 -d {d} -c {c} -g 1 -r 0'

    return best_params

# Calculate classification error
def calculate_classification_error(true_labels, predicted_labels):
    num_errors = np.sum(true_labels != predicted_labels)
    total_instances = len(true_labels)
    error_rate = num_errors / total_instances
    classification_error = error_rate * 100
    return classification_error

# Main function
def main():
    # Number of folds
    num_folds = 3
    total_classification_error = 0
    best_accuracy_per_fold = []
    classification_error_per_fold = []

    # Iterate over folds
    for fold_num in range(1, num_folds + 1):
        # Load data for fold
        tr_pca, T_tr, val_pca, T_val, ts_pca, T_ts = load_data(fold_num)

        # Scale data
        scaled_tr_pca, scaled_val_pca, scaled_ts_pca = scale_data(tr_pca, val_pca, ts_pca)

        # Tune parameters using validation data with polynomial kernel
        best_params = tune_parameters_poly(scaled_tr_pca, T_tr, scaled_val_pca, T_val)

        # Train SVM classifier using best parameters
        model = svm_train(T_tr.tolist(), scaled_tr_pca.tolist(), best_params)

        # Predict on test set
        p_label, p_acc, _ = svm_predict(T_ts.tolist(), scaled_ts_pca.tolist(), model)

        # Store the best accuracy for the fold
        best_accuracy_per_fold.append(p_acc[0])

        # Calculate classification error
        classification_error = calculate_classification_error(T_ts, p_label)
        total_classification_error += classification_error

        # Store the classification error for the fold
        classification_error_per_fold.append(classification_error)

        print(f'Fold {fold_num}: Classification Error = {classification_error:.2f}%')

    # Print the best accuracy for each fold
    for fold_num, accuracy in enumerate(best_accuracy_per_fold, start=1):
        print(f'Fold {fold_num}: Best Accuracy (Polynomial-16*20) = {accuracy:.2f}%')

    # Print classification error of each fold
    for fold_num, error in enumerate(classification_error_per_fold, start=1):
        print(f'Fold {fold_num}: Classification Error (Polynomial-16*20) = {error:.2f}%')

    # Calculate average classification error
    average_classification_error = total_classification_error / num_folds
    print(f'Average Classification Error (Polynomial-16*20) = {average_classification_error:.2f}%')

if __name__ == "__main__":
    main()
