import numpy as np

def ranf(m):
    return m * np.random.rand()

def box_muller_transform(mu, sigma):
    u1 = ranf(1)
    u2 = ranf(1)
    z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
    z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)
    return z0 * np.sqrt(sigma) + mu

def generate_2d_gaussian_samples(mu, sigma, num_samples):
    samples = []
    for _ in range(num_samples):
        x, y = box_muller_transform(mu[0], sigma[0, 0]), box_muller_transform(mu[1], sigma[1, 1])
        samples.append([x, y])
    return np.array(samples)

# Parameters for data set A
mu1 = np.array([1, 1])
sigma1 = np.array([[1, 0], [0, 1]])

mu2 = np.array([4, 4])
sigma2 = np.array([[1, 0], [0, 1]])

num_samples_class1 = 60000
num_samples_class2 = 140000

# Generate data set A
class1_data = generate_2d_gaussian_samples(mu1, sigma1, num_samples_class1)
class2_data = generate_2d_gaussian_samples(mu2, sigma2, num_samples_class2)

# Calculate prior probabilities
prior_prob_class1 = num_samples_class1 / (num_samples_class1 + num_samples_class2)
prior_prob_class2 = num_samples_class2 / (num_samples_class1 + num_samples_class2)

# Define the discriminant function Case_I
def discriminant_function(x, mu, sigma, prior_prob):
    sigma_inv = np.linalg.inv(sigma)
    return -0.5 * np.dot(np.dot((x - mu).T, sigma_inv), (x - mu)) + np.log(prior_prob)

# Bayes classification
misclassifications = 0
for sample in class1_data:
    discriminant_val_class1 = discriminant_function(sample, mu1, sigma1, prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, mu2, sigma2, prior_prob_class2)
    if discriminant_val_class1 < discriminant_val_class2:
        misclassifications += 1

for sample in class2_data:
    discriminant_val_class1 = discriminant_function(sample, mu1, sigma1, prior_prob_class1)
    discriminant_val_class2 = discriminant_function(sample, mu2, sigma2, prior_prob_class2)
    if discriminant_val_class1 > discriminant_val_class2:
        misclassifications += 1

error_rate = misclassifications / (num_samples_class1 + num_samples_class2)
Percentage_error_rate = error_rate * 100
print("Error rate:", error_rate)
print("Percentage Error rate:", Percentage_error_rate)
print("Prior probability for Class 1 (P(ω1)):", prior_prob_class1)
print("Prior probability for Class 2 (P(ω2)):", prior_prob_class2)
